import { Video } from "../types/interfaces";

export const videosMock: Video[] = [
    {
        title: 'Vid 1',
        id: 'yimlIZEJwPY'
    },
    {
        title: 'Vid 2',
        id: 's49CT4DTAkw'
    },
    {
        title: 'Vid 3',
        id: 'h7BTVFOAwkQ'
    }
];
